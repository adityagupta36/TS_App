package task.TS_App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TsAppApplication.class, args);
	}

}
