package task.TS_App.models;

public enum App_Role {
    ROLE_ADMIN,
    ROLE_EMPLOYEE
}
