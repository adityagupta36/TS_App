package task.TS_App.exception;

public class NoReportsFoundException extends RuntimeException{
    public NoReportsFoundException(String message) {
        super(message);
    }}
